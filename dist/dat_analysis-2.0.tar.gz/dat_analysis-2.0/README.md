# Python Analysis Package for Folk Lab at UBC
Written by Tim Child
