"""
A collection of generally useful plotting functions or full plots
"""