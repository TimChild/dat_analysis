"""
This package is for converting from Experiment data (i.e. what Igor saves) into a standard
format that I use for the rest of this code. Outside of this package there should be no
reliance on any Experiment/Igor specific information (e.g. sweep_logs)
"""