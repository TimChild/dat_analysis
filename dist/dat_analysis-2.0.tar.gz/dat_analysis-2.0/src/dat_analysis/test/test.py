import dat_analysis.characters as c


print(c.DELTA)